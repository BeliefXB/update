// Exports the "default" icons for usage with module loaders
// Usage:
//   CommonJS:
//     require('tinymce/icons/default')
//   ES2015:
//     import 'tinymce/icons/default'
require('./icons.js');