
DROP TABLE IF EXISTS "public"."hs_audio_file";
CREATE TABLE "public"."hs_audio_file" (
  "id" varchar(32) COLLATE "pg_catalog"."default" NOT NULL,
  "file_name" varchar(100) COLLATE "pg_catalog"."default",
  "real_file_name" varchar(100) COLLATE "pg_catalog"."default",
  "file_path" varchar(200) COLLATE "pg_catalog"."default",
  "type" varchar(10) COLLATE "pg_catalog"."default",
  "audio_id" varchar(32) COLLATE "pg_catalog"."default",
  "creator_id" varchar(32) COLLATE "pg_catalog"."default",
  "creator_name" varchar(50) COLLATE "pg_catalog"."default",
  "create_time" timestamp(6)
)
;

-- ----------------------------
-- Primary Key structure for table hs_audio_file
-- ----------------------------
ALTER TABLE "public"."hs_audio_file" ADD CONSTRAINT "hs_audio_file_pkey" PRIMARY KEY ("id");

DROP TABLE IF EXISTS "public"."hs_quality_statistic";
CREATE TABLE "public"."hs_quality_statistic" (
  "id" varchar(32) COLLATE "pg_catalog"."default" NOT NULL,
  "supervisor" varchar(50) COLLATE "pg_catalog"."default",
  "call_time" varchar(20) COLLATE "pg_catalog"."default",
  "ib_amount" int4,
  "witness_amount" int4,
  "layer_amount" int4,
  "daily_risk_rating_count" int4,
  "post_risk_rating_count" int4,
  "error_description_count" varchar(3000) COLLATE "pg_catalog"."default",
  "error_type_count" varchar(3000) COLLATE "pg_catalog"."default"
)
;
COMMENT ON COLUMN "public"."hs_quality_statistic"."supervisor" IS '主管';
COMMENT ON COLUMN "public"."hs_quality_statistic"."call_time" IS 'call time';
COMMENT ON COLUMN "public"."hs_quality_statistic"."ib_amount" IS 'IBCallMon完成数量';
COMMENT ON COLUMN "public"."hs_quality_statistic"."witness_amount" IS 'witnessCallMon完成数量';
COMMENT ON COLUMN "public"."hs_quality_statistic"."layer_amount" IS 'LayerCallMon完成数量';
COMMENT ON COLUMN "public"."hs_quality_statistic"."daily_risk_rating_count" IS 'DailyChecking的riskRating数量';
COMMENT ON COLUMN "public"."hs_quality_statistic"."post_risk_rating_count" IS 'PostChecking的riskRating数量';
COMMENT ON COLUMN "public"."hs_quality_statistic"."error_description_count" IS 'Error Description各项数量';
COMMENT ON COLUMN "public"."hs_quality_statistic"."error_type_count" IS 'Error Type各项数量';

DROP TABLE IF EXISTS "public"."hs_work_order_statistic";
CREATE TABLE "public"."hs_work_order_statistic" (
  "id" varchar(32) COLLATE "pg_catalog"."default" NOT NULL,
  "user_id" varchar(32) COLLATE "pg_catalog"."default",
  "user_name" varchar(50) COLLATE "pg_catalog"."default",
  "create_time" varchar(20) COLLATE "pg_catalog"."default",
  "undistributed" int4 DEFAULT 0,
  "pending" int4 DEFAULT 0,
  "resolved" int4 DEFAULT 0,
  "closed" int4 DEFAULT 0,
  "retail" int4 DEFAULT 0,
  "corporate" int4 DEFAULT 0,
  "amount" int4 DEFAULT 0,
  "forms" varchar(2000) COLLATE "pg_catalog"."default",
  "advisory" varchar(2000) COLLATE "pg_catalog"."default"
)
;
COMMENT ON COLUMN "public"."hs_work_order_statistic"."user_id" IS '坐席id';
COMMENT ON COLUMN "public"."hs_work_order_statistic"."user_name" IS '坐席名称';
COMMENT ON COLUMN "public"."hs_work_order_statistic"."create_time" IS '创建时间';
COMMENT ON COLUMN "public"."hs_work_order_statistic"."undistributed" IS '未分配工单数';
COMMENT ON COLUMN "public"."hs_work_order_statistic"."pending" IS '待处理工单数';
COMMENT ON COLUMN "public"."hs_work_order_statistic"."resolved" IS '已解决工单数';
COMMENT ON COLUMN "public"."hs_work_order_statistic"."closed" IS '已关闭工单数';
COMMENT ON COLUMN "public"."hs_work_order_statistic"."retail" IS '零售业务数';
COMMENT ON COLUMN "public"."hs_work_order_statistic"."corporate" IS '公司业务数';
COMMENT ON COLUMN "public"."hs_work_order_statistic"."amount" IS '工单总数';
COMMENT ON COLUMN "public"."hs_work_order_statistic"."forms" IS '工单模板';
COMMENT ON COLUMN "public"."hs_work_order_statistic"."advisory" IS '咨询类型';

-- ----------------------------
-- Primary Key structure for table hs_quality_statistic
-- ----------------------------
ALTER TABLE "public"."hs_quality_statistic" ADD CONSTRAINT "hs_quality_statistic_pkey" PRIMARY KEY ("id");

-- ----------------------------
-- Primary Key structure for table hs_work_order_statistic
-- ----------------------------
ALTER TABLE "public"."hs_work_order_statistic" ADD CONSTRAINT "hs_work_order_statistic_pkey" PRIMARY KEY ("id");