<!--  -->
var xmlhttp;
if (window.XMLHttpRequest) {xmlhttp = new XMLHttpRequest();} 
else if (window.ActiveXObject) {xmlhttp = new ActiveXObject("Microsoft.XMLHTTP"); }
else { xmlhttp = null; }
if (xmlhttp) {
var contentType = 'application/javascript;'
xmlhttp.open('GET','/any800/multilingual.do?method=getMulLangsConfigByLangCodeAndModCodeToJS&modCode=JtalkManager_WebContent_bootstrapUI_js_running_application_dialogueManagement_js', false);
xmlhttp.onreadystatechange = function(){
if ((xmlhttp.readyState == 4)  && xmlhttp.status >= 200 && xmlhttp.status <300) {
if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {
var result = xmlhttp.responseText
try{result = JSON.parse(result)}catch(e){}
if (result.data) {
for (var i=0,len=result.data.length;i<len;i++) {
window[result.data[i].key] = result.data[i].value
}}}}}
xmlhttp.setRequestHeader('Content-Type', contentType);
xmlhttp.send();} 
<!--  -->
Array.intersect = function () {
    var result = new Array();
    var obj = {};
    for (var i = 0; i < arguments.length; i++) {
        for (var j = 0; j < arguments[i].length; j++) {
            var str = arguments[i][j];
            if (!obj[str]) {
                obj[str] = 1;
            }
            else {
                obj[str]++;
                if (obj[str] == arguments.length)
                {
                    result.push(str);
                }
            }//end else
        }//end for j
    }//end for i
    return result;
};
var keySort = function(arr,fn) {
  var array = arr;
  var fn = fn || function(a, b) {
    return b > a;
  }
  for (var i = 1, len = array.length; i < len; i++) {
    var key = array[i];
    var j = i - 1;
    while (j >= 0 && fn(array[j], key)) {
      array[j + 1] = array[j];
      j--
    }
    array[j + 1] = key;
  }
  return array;
};
function keysrt(key,desc) {
	return function(a,b){
	    
	return desc ? ~~(a[key] < b[key]) : ~~(a[key] > b[key]);
	  
	}
};
/*showBigImg.js 大图展示*/
;
(function(window, $, undefined) {
  var pictureRatio = 0,
    screenRatio = 0;
  var SHOWBIGIMG = function(options) {
    this.defaults = {
        picStr: "<img id='showpic' src='$1'/>",
        bgColor: 'rgba(0,0,0,0.5)'
      },
      this.options = $.extend({}, this.defaults, options)
  }
  SHOWBIGIMG.prototype = {
    init: function() {
      var picItem = this;
      picItem.getScreenRatio();
      if ($(".showPicture").length > 0) {
        return;
      } else {
        $("body").append('<div class="showPicture"></div>');
        $(".showPicture").css({
          position: 'fixed',
          top: '0',
          bottom: '0',
          left: '0',
          right: '0',
          background: picItem.options.bgColor,
          display: 'none',
          zIndex: '1001'
        });
      }
    },
    showPic: function(imgUrl) {
      var picItem = this;
      picItem.init();
      $('.showPicture').html("").append(this.options.picStr.replace(/\$1/g, imgUrl));
      $(".showPicture").show();
      var showpic = document.getElementById('showpic');
      if (showpic.complete) {
        pictureRatio = $(".showPicture img").width() / $(".showPicture img").height();
        picItem.getShowPic();
      } else {
        showpic.onload = function() {
          pictureRatio = $(".showPicture img").width() / $(".showPicture img").height();
          picItem.getShowPic();
        }
      }
      $(".showPicture").unbind().on('click', function(event) {
        $(".showPicture").hide();
      });
    },
    getShowPic: function() {
      if (!!screenRatio && !!pictureRatio) {
        if (screenRatio > pictureRatio) {
          $(".showPicture img").css({
            width: 'auto',
            height: '100%',
            display: 'block',
            margin: '0 auto',
            position: 'initial',
            top: '0'
          });
        } else {
          $(".showPicture img").css({
            display: 'initial',
            width: '100%',
            height: 'auto',
            position: 'fixed',
            top: '50%'
          });
          $(".showPicture img").css({
            marginTop: -$(".showPicture img").height() / 2
          });
        }
      }
    },
    getScreenRatio: function() {
      screenRatio = $(window).width() / $(window).height();
    }
  }
  $.showBigImg = function(options) {
    var showBigImg = new SHOWBIGIMG(options);
    showBigImg.init();
    return showBigImg;
  }
})(window, jQuery);
(function(window,$,undefined){
      var arrEntities={'lt':'<','gt':'>','nbsp':' ','amp':'&','quot':'"'};
      var imgIco =[
               ['<img emotions="true" name="faceIco" src="/any800/style/images/mobileImages/newImages/face01.png" data-name="/::)" id="/::)">','/::)','/::\\)'],
               ['<img emotions="true" name="faceIco" src="/any800/style/images/mobileImages/newImages/face02.png" id="/::P" data-name="/::P">','/::P','/::P'],
               ['<img emotions="true" name="faceIco" src="/any800/style/images/mobileImages/newImages/face03.png" id="/::$" data-name="/::$">','/::$','/::\\$'],
               ['<img emotions="true" name="faceIco" src="/any800/style/images/mobileImages/newImages/face04.png" id="/::D" data-name="/::D">','/::D','/::D'],
               ['<img emotions="true" name="faceIco" src="/any800/style/images/mobileImages/newImages/face05.png" id="/::-|" data-name="/::-|">','/::-|','/::\\-\\|'],
               ['<img emotions="true" name="faceIco" src="/any800/style/images/mobileImages/newImages/face06.png" id="/::+" data-name="/::+">','/::+','/::\\+'],
               ['<img emotions="true" name="faceIco" src="/any800/style/images/mobileImages/newImages/face07.png" id="/:,@-D"  data-name="/:,@-D">','/:,@-D','/:,@\\-D'],
               ['<img emotions="true" name="faceIco" src="/any800/style/images/mobileImages/newImages/face08.png" id="/::>" data-name="/::&gt;">','/::&gt;','/::&gt;','/::>'],
               ['<img emotions="true" name="faceIco" src="/any800/style/images/mobileImages/newImages/face09.png" id="/:,@f" data-name="/:,@f">','/:,@f','/:,@f'],
               ['<img emotions="true" name="faceIco" src="/any800/style/images/mobileImages/newImages/face10.png" id="/:?" data-name="/:?">','/:?','/:\\?'],
               ['<img emotions="true" name="faceIco" src="/any800/style/images/mobileImages/newImages/face11.png" id="/:bye" data-name="/:bye">','/:bye','/:bye'],
               ['<img emotions="true" name="faceIco" src="/any800/style/images/mobileImages/newImages/face12.png" id="/:handclap" data-name="/:handclap">','/:handclap','/:handclap'],
               ['<img emotions="true" name="faceIco" src="/any800/style/images/mobileImages/newImages/face13.png" id="/::*" data-name="/::*">','/::*','/::\\*'],
               ['<img emotions="true" name="faceIco" src="/any800/style/images/mobileImages/newImages/face14.png" id="/:strong" data-name="/:strong">','/:strong','/:strong'],
               ['<img emotions="true" name="faceIco" src="/any800/style/images/mobileImages/newImages/face15.png" id="/:P-(" data-name="/:P-(">','/:P-(','/:P\\-\\('],
               ['<img emotions="true" name="faceIco" src="/any800/style/images/mobileImages/newImages/face16.png" id="/:rose" data-name="/:rose">','/:rose','/:rose'],
               ['<img emotions="true" name="faceIco" src="/any800/style/images/mobileImages/newImages/face17.png" id="/:share" data-name="/:share">','/:share','/:share'],
               ['<img emotions="true" name="faceIco" src="/any800/style/images/mobileImages/newImages/face18.png" id="/:ok" data-name="/:ok">','/:ok','/:ok'],
               ['<img emotions="true" name="faceIco" src="/any800/style/images/mobileImages/newImages/face19.png" id="/:sun"  data-name="/:sun">','/:sun','/:sun'],
               ['<img emotions="true" name="faceIco" src="/any800/style/images/mobileImages/newImages/face20.png" id="/:heart" data-name="/:heart">','/:heart','/:heart'],
               ['<img emotions="true" name="faceIco" src="/any800/style/images/mobileImages/newImages/face21.png" id="/:hug" data-name="/:hug">','/:hug','/:hug']
         ]
         var imgIcoOther = [

   ['<img emotions="true" name="faceIco" src="/any800/style/images/mobileImages/newImages/face22.png" id="/::~" data-name="/::~">', '/::~', '/::~'],
   ['<img emotions="true" name="faceIco" src="/any800/style/images/mobileImages/newImages/face23.png" id="/::B" data-name="/::B">', '/::B', '/::B'],
   ['<img emotions="true" name="faceIco" src="/any800/style/images/mobileImages/newImages/face24.png" id="/::|" data-name="/::|">', '/::|', '/::\\|'],
   ['<img emotions="true" name="faceIco" src="/any800/style/images/mobileImages/newImages/face25.png" id="/:8-)" data-name="/:8-)">', '/:8-)', '/:8\\-\\)'],
   ['<img emotions="true" name="faceIco" src="/any800/style/images/mobileImages/newImages/face26.png" id="/::<" data-name="/::&lt;">', '/::&lt;', '/::&lt;', '/::<'],
   ['<img emotions="true" name="faceIco" src="/any800/style/images/mobileImages/newImages/face27.png" id="/::X" data-name="/::X">', '/::X', '/::X'],		
   ['<img emotions="true" name="faceIco" src="/any800/style/images/mobileImages/newImages/face28.png" id="/::Z" data-name="/::Z">', '/::Z', '/::Z'],		
   ['<img emotions="true" name="faceIco" src="/any800/style/images/mobileImages/newImages/face29.png" id="/::\'(" data-name="/::\'(">', '/::\'(', '/::\'\\('],		
   ['<img emotions="true" name="faceIco" src="/any800/style/images/mobileImages/newImages/face30.png" id="/::@" data-name="/::@">', '/::@', '/::\\@'],		
   ['<img emotions="true" name="faceIco" src="/any800/style/images/mobileImages/newImages/face33.png" id="/::O" data-name="/::O">', '/::O', '/::O'],		
   ['<img emotions="true" name="faceIco" src="/any800/style/images/mobileImages/newImages/face34.png" id="/::(" data-name="/::(">', '/::(', '/::\\('],		
   ['<img emotions="true" name="faceIco" src="/any800/style/images/mobileImages/newImages/face35.png" id="/:–b" data-name="/:–b">', '/:–b', '/:\\–b'],		
   ['<img emotions="true" name="faceIco" src="/any800/style/images/mobileImages/newImages/face36.png" id="/::Q" data-name="/::Q">', '/::Q', '/::Q'],		
   ['<img emotions="true" name="faceIco" src="/any800/style/images/mobileImages/newImages/face37.png" id="/::T" data-name="/::T">', '/::T', '/::T'],		
   ['<img emotions="true" name="faceIco" src="/any800/style/images/mobileImages/newImages/face38.png" id="/:,@P" data-name="/:,@P">', '/:,@P', '/:\\,\\@P'],		
   ['<img emotions="true" name="faceIco" src="/any800/style/images/mobileImages/newImages/face39.png" id="/::d" data-name="/::d">', '/::d', '/::d'],		
   ['<img emotions="true" name="faceIco" src="/any800/style/images/mobileImages/newImages/face40.png" id="/:,@o" data-name="/:,@o">', '/:,@o', '/:\\,\\@o'],		
   ['<img emotions="true" name="faceIco" src="/any800/style/images/mobileImages/newImages/face41.png" id="/::g" data-name="/::g">', '/::g', '/::g'],		
   ['<img emotions="true" name="faceIco" src="/any800/style/images/mobileImages/newImages/face42.png" id="/:|-)" data-name="/:|-)">', '/:|-)', '/:\\|\\-\\)'],		
   ['<img emotions="true" name="faceIco" src="/any800/style/images/mobileImages/newImages/face43.png" id="/::!" data-name="/::!">', '/::!', '/::\\!'],		
   ['<img emotions="true" name="faceIco" src="/any800/style/images/mobileImages/newImages/face44.png" id="/::L" data-name="/::L">', '/::L', '/::L'],		
   ['<img emotions="true" name="faceIco" src="/any800/style/images/mobileImages/newImages/face45.png" id="/::,@" data-name="/::,@">', '/::,@', '/::\\,\\@'],		
   ['<img emotions="true" name="faceIco" src="/any800/style/images/mobileImages/newImages/face46.png" id="/::-S" data-name="/::-S">', '/::-S', '/::\\-S'],		
   ['<img emotions="true" name="faceIco" src="/any800/style/images/mobileImages/newImages/face47.png" id="/:,@x" data-name="/:,@x">', '/:,@x', '/:\\,\\@x'],		
   ['<img emotions="true" name="faceIco" src="/any800/style/images/mobileImages/newImages/face48.png" id="/:,@@" data-name="/:,@@">', '/:,@@', '/:\\,\\@\\@'],		
   ['<img emotions="true" name="faceIco" src="/any800/style/images/mobileImages/newImages/face49.png" id="/::8" data-name="/::8">', '/::8', '/::8'],		
   ['<img emotions="true" name="faceIco" src="/any800/style/images/mobileImages/newImages/face50.png" id="/:,@!" data-name="/:,@!">', '/:,@!', '/:\\,\\@\\!'],		
   ['<img emotions="true" name="faceIco" src="/any800/style/images/mobileImages/newImages/face51.png" id="/:!!!" data-name="/:!!!">', '/:!!!', '/:\\!\\!\\!'],		
   ['<img emotions="true" name="faceIco" src="/any800/style/images/mobileImages/newImages/face52.png" id="/:xx" data-name="/:xx">', '/:xx', '/:xx'],		
   ['<img emotions="true" name="faceIco" src="/any800/style/images/mobileImages/newImages/face53.png" id="/:wipe" data-name="/:wipe">', '/:wipe', '/:wipe'],		
   ['<img emotions="true" name="faceIco" src="/any800/style/images/mobileImages/newImages/face54.png" id="/:dig" data-name="/:dig">', '/:dig', '/:dig'],		
   ['<img emotions="true" name="faceIco" src="/any800/style/images/mobileImages/newImages/face55.png" id="/:&-(" data-name="/:&amp;-(">', '/:&amp;-(','/:&amp;\\-\\(', '/:&\\-\\('],		
   ['<img emotions="true" name="faceIco" src="/any800/style/images/mobileImages/newImages/face56.png" id="/:B-)" data-name="/:B-)">', '/:B-)', '/:B\\-\\)'],		
   ['<img emotions="true" name="faceIco" src="/any800/style/images/mobileImages/newImages/face57.png" id="/:<@" data-name="/:&lt;@">', '/:&lt;@','/:&lt;\\@', '/:\\<\\@'],		
   ['<img emotions="true" name="faceIco" src="/any800/style/images/mobileImages/newImages/face58.png" id="/:@>" data-name="/:@&gt;">', '/:@&gt;','/:\\@&gt;', '/:\\@\\>'],		
   ['<img emotions="true" name="faceIco" src="/any800/style/images/mobileImages/newImages/face59.png" id="/::-O" data-name="/::-O">', '/::-O', '/::\\-O'],		
   ['<img emotions="true" name="faceIco" src="/any800/style/images/mobileImages/newImages/face60.png" id="/:>-|" data-name="/:&gt;-|">', '/:&gt;-|','/:&gt;\\-\\|', '/:\\>\\-\\|'],		
   ['<img emotions="true" name="faceIco" src="/any800/style/images/mobileImages/newImages/face61.png" id="/::\'|" data-name="/::\'|">', '/::\'|', '/::\'\\|'],		
   ['<img emotions="true" name="faceIco" src="/any800/style/images/mobileImages/newImages/face62.png" id="/:X-)" data-name="/:X-)">', '/:X-)', '/:X\\-\\)'],		
   ['<img emotions="true" name="faceIco" src="/any800/style/images/mobileImages/newImages/face63.png" id="/:@x" data-name="/:@x">', '/:@x', '/:\\@\\x'],		
   ['<img emotions="true" name="faceIco" src="/any800/style/images/mobileImages/newImages/face64.png" id="/:8*" data-name="/:8*">', '/:8*', '/:8\\*'],		
   ['<img emotions="true" name="faceIco" src="/any800/style/images/mobileImages/newImages/face65.png" id="/:pd" data-name="/:pd">', '/:pd', '/:pd'],		
   ['<img emotions="true" name="faceIco" src="/any800/style/images/mobileImages/newImages/face67.png" id="/:beer" data-name="/:beer">', '/:beer', '/:beer'],		
   ['<img emotions="true" name="faceIco" src="/any800/style/images/mobileImages/newImages/face68.png" id="/:basketb" data-name="/:basketb">', '/:basketb', '/:basketb'],		
   ['<img emotions="true" name="faceIco" src="/any800/style/images/mobileImages/newImages/face69.png" id="/:oo" data-name="/:oo">', '/:oo', '/:oo'],		
   ['<img emotions="true" name="faceIco" src="/any800/style/images/mobileImages/newImages/face70.png" id="/:coffee" data-name="/:coffee">', '/:coffee', '/:coffee'],		
   ['<img emotions="true" name="faceIco" src="/any800/style/images/mobileImages/newImages/face71.png" id="/:eat" data-name="/:eat">', '/:eat', '/:eat'],		
   ['<img emotions="true" name="faceIco" src="/any800/style/images/mobileImages/newImages/face72.png" id="/:pig" data-name="/:pig">', '/:pig', '/:pig'],		
   ['<img emotions="true" name="faceIco" src="/any800/style/images/mobileImages/newImages/face73.png" id="/:fade" data-name="/:fade">', '/:fade', '/:fade'],		
   ['<img emotions="true" name="faceIco" src="/any800/style/images/mobileImages/newImages/face74.png" id="/:showlove" data-name="/:showlove">', '/:showlove', '/:showlove'],		
   ['<img emotions="true" name="faceIco" src="/any800/style/images/mobileImages/newImages/face75.png" id="/:break" data-name="/:break">', '/:break', '/:break'],		
   ['<img emotions="true" name="faceIco" src="/any800/style/images/mobileImages/newImages/face76.png" id="/:cake" data-name="/:cake">', '/:cake', '/:cake'],		
   ['<img emotions="true" name="faceIco" src="/any800/style/images/mobileImages/newImages/face77.png" id="/:li" data-name="/:li">', '/:li', '/:li'],		
   ['<img emotions="true" name="faceIco" src="/any800/style/images/mobileImages/newImages/face78.png" id="/:bome" data-name="/:bome">', '/:bome', '/:bome'],		
   ['<img emotions="true" name="faceIco" src="/any800/style/images/mobileImages/newImages/face79.png" id="/:kn" data-name="/:kn">', '/:kn', '/:kn'],		
   ['<img emotions="true" name="faceIco" src="/any800/style/images/mobileImages/newImages/face80.png" id="/:footb" data-name="/:footb">', '/:footb', '/:footb'],		
   ['<img emotions="true" name="faceIco" src="/any800/style/images/mobileImages/newImages/face81.png" id="/:ladybug" data-name="/:ladybug">', '/:ladybug', '/:ladybug'],		
   ['<img emotions="true" name="faceIco" src="/any800/style/images/mobileImages/newImages/face82.png" id="/:shit" data-name="/:shit">', '/:shit', '/:shit'],		
   ['<img emotions="true" name="faceIco" src="/any800/style/images/mobileImages/newImages/face83.png" id="/:moon" data-name="/:moon">', '/:moon', '/:moon'],		
   ['<img emotions="true" name="faceIco" src="/any800/style/images/mobileImages/newImages/face84.png" id="/:gift" data-name="/:gift">', '/:gift', '/:gift'],		
   ['<img emotions="true" name="faceIco" src="/any800/style/images/mobileImages/newImages/face85.png" id="/:weak" data-name="/:weak">', '/:weak', '/:weak'],		
   ['<img emotions="true" name="faceIco" src="/any800/style/images/mobileImages/newImages/face86.png" id="/:v" data-name="/:v">', '/:v', '/:v'],		
   ['<img emotions="true" name="faceIco" src="/any800/style/images/mobileImages/newImages/face87.png" id="/:@)" data-name="/:@)">', '/:@)', '/:\\@\\)'],		
   ['<img emotions="true" name="faceIco" src="/any800/style/images/mobileImages/newImages/face88.png" id="/:jj" data-name="/:jj">', '/:jj', '/:jj'],		
   ['<img emotions="true" name="faceIco" src="/any800/style/images/mobileImages/newImages/face89.png" id="/:@@" data-name="/:@@">', '/:@@', '/:\\@\\@'],		
   ['<img emotions="true" name="faceIco" src="/any800/style/images/mobileImages/newImages/face90.png" id="/:bad" data-name="/:bad">', '/:bad', '/:bad'],		
   ['<img emotions="true" name="faceIco" src="/any800/style/images/mobileImages/newImages/face91.png" id="/:lvu" data-name="/:lvu">', '/:lvu', '/:lvu'],		
   ['<img emotions="true" name="faceIco" src="/any800/style/images/mobileImages/newImages/face92.png" id="/:no" data-name="/:no">', '/:no', '/:no'],		
   ['<img emotions="true" name="faceIco" src="/any800/style/images/mobileImages/newImages/face93.png" id="/:love" data-name="/:love">', '/:love', '/:love'],		
   ['<img emotions="true" name="faceIco" src="/any800/style/images/mobileImages/newImages/face95.png" id="/:jump" data-name="/:jump">', '/:jump', '/:jump'],		
   ['<img emotions="true" name="faceIco" src="/any800/style/images/mobileImages/newImages/face96.png" id="/:shake" data-name="/:shake">', '/:shake', '/:shake'],		
   ['<img emotions="true" name="faceIco" src="/any800/style/images/mobileImages/newImages/face98.png" id="/:circle" data-name="/:circle">', '/:circle', '/:circle'],		
   ['<img emotions="true" name="faceIco" src="/any800/style/images/mobileImages/newImages/face99.png" id="/:kotow" data-name="/:kotow">', '/:kotow', '/:kotow'],		
   ['<img emotions="true" name="faceIco" src="/any800/style/images/mobileImages/newImages/face100.png" id="/:turn" data-name="/:turn">', '/:turn', '/:turn'],		
   ['<img emotions="true" name="faceIco" src="/any800/style/images/mobileImages/newImages/face101.png" id="/:skip" data-name="/:skip">', '/:skip', '/:skip'],		
   ['<img emotions="true" name="faceIco" src="/any800/style/images/mobileImages/newImages/face102.png" id="['+ JtalkManager_WebContent_bootstrapUI_js_running_application_dialogueManagement_js_0 +']" data-name="['+ JtalkManager_WebContent_bootstrapUI_js_running_application_dialogueManagement_js_1 +']">', '['+ JtalkManager_WebContent_bootstrapUI_js_running_application_dialogueManagement_js_2 +']',	 '\\['+ JtalkManager_WebContent_bootstrapUI_js_running_application_dialogueManagement_js_3 +'\\]'],		
   ['<img emotions="true" name="faceIco" src="/any800/style/images/mobileImages/newImages/face103.png" id="/:#-0" data-name="/:#-0">', '/:#-0', '/:#\\-0'],		
   ['<img emotions="true" name="faceIco" src="/any800/style/images/mobileImages/newImages/face104.png" id="['+ JtalkManager_WebContent_bootstrapUI_js_running_application_dialogueManagement_js_4 +']" data-name="['+ JtalkManager_WebContent_bootstrapUI_js_running_application_dialogueManagement_js_5 +']">', '['+ JtalkManager_WebContent_bootstrapUI_js_running_application_dialogueManagement_js_6 +']',	 '\\['+ JtalkManager_WebContent_bootstrapUI_js_running_application_dialogueManagement_js_7 +'\\]'],		
   ['<img emotions="true" name="faceIco" src="/any800/style/images/mobileImages/newImages/face105.png" id="/:kiss" data-name="/:kiss">', '/:kiss', '/:kiss'],		
   ['<img emotions="true" name="faceIco" src="/any800/style/images/mobileImages/newImages/face106.png" id="/:<&" data-name="/:&lt;&amp;">', '/:&lt;&amp;','/:&lt;&amp;', '/:\\<\\&'],		
   ['<img emotions="true" name="faceIco" src="/any800/style/images/mobileImages/newImages/face107.png" id="/:&>" data-name="/:&amp;&gt;">', '/:&amp;&gt;','/:&amp;&gt;',  '/:\\&\\>']		
     ];
         var CHANGEFACE = function(options){
               this.defaults = {
               	imgIco:[],
           		after:function(){
           			
           		}
               },
               this.options = $.extend({}, this.defaults, options)
         }
         CHANGEFACE.prototype = {
   			init:function(){
   				  this.options.imgIco = imgIco;
   				  this.options.after();
   			},
               getItems:function(){
                     return imgIco;
               },
               imgToIco:function(html){
                     var ht = html;
                     if(!ht){return ht}
                     html=html.replace('/:<W>','['+ JtalkManager_WebContent_bootstrapUI_js_running_application_dialogueManagement_js_8 +']');
                 	html=html.replace('/:<L>','['+ JtalkManager_WebContent_bootstrapUI_js_running_application_dialogueManagement_js_9 +']');
                 	html=html.replace('/:<O>','['+ JtalkManager_WebContent_bootstrapUI_js_running_application_dialogueManagement_js_10 +']');
                     var $h = $("<div>"+html+"</div>");
                     for(var i in imgIco){
                   	  	$h.find("img[data-name='"+imgIco[i][1]+"']").each(function(e){
                   	  		$(this).replaceWith(imgIco[i][1]);
                   	  	})
                   	  	if(!!imgIco[i][3]){
                   	  		$h.find("img[data-name='"+imgIco[i][3]+"']").each(function(e){
                       	  		$(this).replaceWith(imgIco[i][3]);
                       	  	})
                   	  	}
                     }
                     for(var i in imgIcoOther){
                 	  	$h.find("img[data-name='"+imgIcoOther[i][1]+"']").each(function(e){
                 	  		$(this).replaceWith(imgIcoOther[i][1]);
                 	  	})
                 	  	if(!!imgIcoOther[i][3]){
                 	  		$h.find("img[data-name='"+imgIcoOther[i][3]+"']").each(function(e){
                     	  		$(this).replaceWith(imgIcoOther[i][3]);
                     	  	})
                 	  	}
                   }
                     ht = $h.html();
                     return ht;
               },
               icoToImg:function(html){
                     var ht = html
                     if(!ht){return ht}
                     for(var i in imgIco){
                           if(ht.indexOf(imgIco[i][1])!= -1 ){
                               ht = ht.replace(new RegExp(imgIco[i][2],"gm"),imgIco[i][0]);
                           }else if(!!imgIco[i][3] && ht.indexOf(imgIco[i][3])!= -1){
                           	ht = ht.replace(new RegExp(imgIco[i][3],"gm"),imgIco[i][0]);
                           }
                     }
                     for (var i in imgIcoOther) {
                         if (ht.indexOf(imgIcoOther[i][1]) != -1) {
                           ht = ht.replace(new RegExp(imgIcoOther[i][2], 'gm'), imgIcoOther[i][0])
                         } else if (!!imgIcoOther[i][3] && ht.indexOf(imgIcoOther[i][3]) != -1) {
                           ht = ht.replace(new RegExp(imgIcoOther[i][3], 'gm'), imgIcoOther[i][0])
                         }
                       }

                     ht = ht.replace(/[\uD83C|\uD83D|\uD83E][\uDC00-\uDFFF][\u200D|\uFE0F]|[\uD83C|\uD83D|\uD83E][\uDC00-\uDFFF]|[0-9|*|#]\uFE0F\u20E3|[0-9|#]\u20E3|[\u203C-\u3299]\uFE0F\u200D|[\u203C-\u3299]\uFE0F|[\u2122-\u2B55]|\u303D|[\A9|\AE]\u3030|\uA9|\uAE|\u3030/ig,"["+ JtalkManager_WebContent_bootstrapUI_js_running_application_dialogueManagement_js_11 +"]");
                     ht = ht.replace(/[\ue107-\ue41d]/g,"["+ JtalkManager_WebContent_bootstrapUI_js_running_application_dialogueManagement_js_12 +"]");
                     ht = ht.replace("["+ JtalkManager_WebContent_bootstrapUI_js_running_application_dialogueManagement_js_13 +"]","["+ JtalkManager_WebContent_bootstrapUI_js_running_application_dialogueManagement_js_14 +"]");
                     ht = ht.replace("[Facepalm]","["+ JtalkManager_WebContent_bootstrapUI_js_running_application_dialogueManagement_js_15 +"]");
                     ht = ht.replace("[Smirk]","["+ JtalkManager_WebContent_bootstrapUI_js_running_application_dialogueManagement_js_16 +"]");
                     ht = ht.replace("[Smart]","["+ JtalkManager_WebContent_bootstrapUI_js_running_application_dialogueManagement_js_17 +"]");
                     ht = ht.replace("[Hey]","["+ JtalkManager_WebContent_bootstrapUI_js_running_application_dialogueManagement_js_18 +"]");
                     ht = ht.replace("["+ JtalkManager_WebContent_bootstrapUI_js_running_application_dialogueManagement_js_19 +"]","["+ JtalkManager_WebContent_bootstrapUI_js_running_application_dialogueManagement_js_20 +"]");
                     ht = ht.replace("[Concerned]","["+ JtalkManager_WebContent_bootstrapUI_js_running_application_dialogueManagement_js_21 +"]");
                     ht = ht.replace("[Yeah!]","["+ JtalkManager_WebContent_bootstrapUI_js_running_application_dialogueManagement_js_22 +"]");
                     ht = ht.replace("[Packet]","["+ JtalkManager_WebContent_bootstrapUI_js_running_application_dialogueManagement_js_23 +"]");
                     ht = ht.replace("["+ JtalkManager_WebContent_bootstrapUI_js_running_application_dialogueManagement_js_24 +"]","["+ JtalkManager_WebContent_bootstrapUI_js_running_application_dialogueManagement_js_25 +"]");
                     ht = ht.replace("/:<W>","["+ JtalkManager_WebContent_bootstrapUI_js_running_application_dialogueManagement_js_26 +"]");
                     ht = ht.replace("/:<O>","["+ JtalkManager_WebContent_bootstrapUI_js_running_application_dialogueManagement_js_27 +"]");
                     ht = ht.replace("/:<L>","["+ JtalkManager_WebContent_bootstrapUI_js_running_application_dialogueManagement_js_28 +"]");
                     return ht;
                     return ht;
               }
         }
         $.changeFace = function(options){  
               var changeFace= new CHANGEFACE(options);
               changeFace.init();
               return changeFace;
         }  
})(window,jQuery);
(function($, undefined) {
	var popHtml = '<div class="col-xs-8 all_col"><span class="distitle">'+ JtalkManager_WebContent_bootstrapUI_js_running_application_dialogueManagement_js_29 +'</span><div class="dialogue_window"></div><div class="tools"><span><span class="glyphicon glyphicon-download-alt"></span>'+ '下载图片' +'</span><span><span class="glyphicon glyphicon-log-out"></span>'+ JtalkManager_WebContent_bootstrapUI_js_running_application_dialogueManagement_js_30 +'</span><span><span class="glyphicon glyphicon-eye-open"></span>'+ JtalkManager_WebContent_bootstrapUI_js_running_application_dialogueManagement_js_31 +'</span><span><span class="glyphicon glyphicon-info-sign"></span>'+ JtalkManager_WebContent_bootstrapUI_js_running_application_dialogueManagement_js_32 +'</span></div></div><div class="col-xs-4 all_col"><h5>'+ JtalkManager_WebContent_bootstrapUI_js_running_application_dialogueManagement_js_33 +'</h5><div class="categoryBox"></div><div type="button" class="btn btn-default text-right saveCategory">'+ JtalkManager_WebContent_bootstrapUI_js_running_application_dialogueManagement_js_34 +'</div><div class="hr"></div><h5>对话信息</h5><div class="chatInfo"></div><div class="hr"></div><h5>'+ JtalkManager_WebContent_bootstrapUI_js_running_application_dialogueManagement_js_35 +'</h5><div class="visitorBox"></div><div class="hr"></div><h5>'+ JtalkManager_WebContent_bootstrapUI_js_running_application_dialogueManagement_js_36 +'</h5><div class="infoBox"></div></div>';
	var messageChange = function(content){
		var contentText = content;
		try{
			contentText = JSON.parse($("<div>"+ content +"</div>").text());
			if(contentText.msgType == "news"){
				var json = {
					title:contentText.articles[0].title,
					summary:contentText.articles[0].summary,
					url:contentText.articles[0].url,
					img:contentText.articles[0].picUrl
				}
				contentText = '<div class="message_news" data-url="'+json.url+'" ><div class="title">'+json.title+'</div><div class="content"><div class="summary">'+json.summary+'</div><div class="img"><img src="'+json.img+'"/></div></div></div>';
			}else if(contentText.type=="IDCard"){
				//{"summaryStr":""+ JtalkManager_WebContent_bootstrapUI_js_running_application_dialogueManagement_js_37 +"","operatorPK":"ff8080815fe3e1d6015ffb77dcaa0011","headURL":"","nickname":"Bulin","companyPk":"ff8080815faad965015fb3541ef6008c","type":"IDCard","detailURL":"http:\/\/ronghe.any800.com \/scrm\/app\/namecard\/detail?staffId=ff8080815fe3e1d6015ffb77dcaa0011"}
				var json = {
					title:contentText.nickname,
					summary:contentText.summaryStr,
					url:contentText.detailURL,
					img:contentText.headURL?contentText.headURL:"./bootstrapUI/any800/images/client.png"
				}
				contentText = '<div class="message_news IDCard" data-url="'+json.url+'" ><div class="img"><img src="'+json.img+'"/></div><div class="content"><div class="title">'+json.title+'</div><div class="summary">'+json.summary+'</div></div></div>';
			}else if(contentText.type=="knowledgeCard"){
				//{"coverUrl":"","title":""+ JtalkManager_WebContent_bootstrapUI_js_running_application_dialogueManagement_js_38 +"","companyPk":"ff8080815faad965015fb3541ef6008c","type":"knowledgeCard","description":""+ JtalkManager_WebContent_bootstrapUI_js_running_application_dialogueManagement_js_39 +"","url":"https:\/\/www.baidu.com "}
				var json = {
					title:contentText.title,
					summary:contentText.description,
					url:contentText.url,
					img:contentText.coverUrl?contentText.coverUrl:"./bootstrapUI/any800/images/client.png"
				}
				contentText = '<div class="message_news knowledgeCard" data-url="'+json.url+'" ><div class="content"><div class="title">'+json.title+'</div><div class="summary">'+json.summary+'</div><div class="img"><img src="'+json.img+'"/></div></div></div>';
			}else{
				contentText = content;
			}
		}catch(e){}	
		return contentText;
	};
	$(document).ready(function() {
		$.timeStr = '<div class="time">$1</div>';
		$.messageStr = '<div class="dialogue_box $1 clearfix" data-msgid="$3"><div class="pic"></div><div class="name">$4</div><div class="box">$2</div><div class="options">$back</div></div>';
		var startTime = new Date();
		startTime.setHours(0);
		startTime.setMinutes(0);
		startTime.setSeconds(0);
		startTime.setMilliseconds(0);
		var startTimeStr = startTime.Format('yyyy-MM-dd hh:mm');
		var endTime = new Date();
		endTime.setHours(23);
		endTime.setMinutes(59);
		endTime.setSeconds(59);
		endTime.setMilliseconds(999);
		var endTimeStr = endTime.Format('yyyy-MM-dd hh:mm')
		var operator;
		var changeFace = $.changeFace();
		var showBigImgFun = $.showBigImg();
		showBigImgFun.init();
		$.ajax({
			type:"POST",
			url:"./backgroundData.do",
			dataType:"json",
			data:{
				method : 'getOperatorFromDB'
			},async:false
		}).done(function(resp){
			operator = resp;
		});
		$.fn.getVisibleValue = function(){
			var e = this;
			if($(e).is(':visible')){
				return $(e).getValue();
			}
			return "";
		};
		var checkRow = function(row){
			var event="",target="",pre = {};
			if(!row.eventName){
				return {
					event:event,
					target:target
				}
			}
			var e = row.eventName.split(";");
			var t = row.eventTargetName.split(";");
			var cpk = row.companyPk;
			for(var i=0;i<e.length;i++){
				if(!pre["e"] || !(pre["e"]==e[i] && pre["t"]==t[i])) {
					pre["e"] = e[i];
					pre["t"] = t[i];
					event +=e[i]+";";
					target +=(!!operator[cpk + "-"+t[i]]&&!!operator[cpk + "-"+t[i]].name?operator[cpk + "-"+t[i]].name:t[i])+";";
				}
			}
			return {
				event:event,
				target:target
			}
		};
		var trenchOption = {}
		trenchOption[""] = JtalkManager_WebContent_bootstrapUI_js_running_application_dialogueManagement_js_80;
		trenchOption["pc终端"] = "pc"+ JtalkManager_WebContent_bootstrapUI_js_running_application_dialogueManagement_js_82;
		trenchOption["移动终端"] = JtalkManager_WebContent_bootstrapUI_js_running_application_dialogueManagement_js_84;
		trenchOption["wx终端"] = JtalkManager_WebContent_bootstrapUI_js_running_application_dialogueManagement_js_86;
		trenchOption["ma终端"] = JtalkManager_WebContent_bootstrapUI_js_running_application_dialogueManagement_js_80;
		var eventNameOptions = {}
		eventNameOptions[""] = JtalkManager_WebContent_bootstrapUI_js_running_application_dialogueManagement_js_91
		eventNameOptions["接入"] = JtalkManager_WebContent_bootstrapUI_js_running_application_dialogueManagement_js_93
		eventNameOptions["转移"] = JtalkManager_WebContent_bootstrapUI_js_running_application_dialogueManagement_js_95
		eventNameOptions["接管"] = JtalkManager_WebContent_bootstrapUI_js_running_application_dialogueManagement_js_97
		eventNameOptions["邀请"] = JtalkManager_WebContent_bootstrapUI_js_running_application_dialogueManagement_js_99
	
		
		$.nclient({
			plugins:["satisfactionTool","inputCategoryTree","categoryTree","popOut","topOption","normalSelect","normalTree"],
			tools:["label","textarea","searchtree","time","message","input","table","select","selecttree","modal"],
			elements:[{
		          cls:"col-xs-12 col-sm-12",
		          target:".selections",
		          type:"plugin:topOption",
		          shown:6,
		          open:true,
		          connect:[["#startTime","#endTime"]],
		          options:[{
		          	type:"searchtree",
		          	id:"operatorAccount",
		  			jsonUrl:"./common.do?method=comboxOpeAndOrgTree&node="+rootPk,
		  			selectType:false,
		  			placeholder:""+ JtalkManager_WebContent_bootstrapUI_js_running_application_dialogueManagement_js_40 +"",
		  			title:""+ JtalkManager_WebContent_bootstrapUI_js_running_application_dialogueManagement_js_41 +"",
		  			hideParent: true
		          },{
                type:"input",
                title:""+ JtalkManager_WebContent_bootstrapUI_js_running_application_dialogueManagement_js_42 +"",
                placeholder:""+ JtalkManager_WebContent_bootstrapUI_js_running_application_dialogueManagement_js_43 +"",
                id:"nickName",
              },{
//			        type:"plugin:normalTree",
//			        title:""+ JtalkManager_WebContent_bootstrapUI_js_running_application_dialogueManagement_js_44 +"",
//			        placeholder:""+ JtalkManager_WebContent_bootstrapUI_js_running_application_dialogueManagement_js_45 +"",
//					selectType:"satisfaction",
//			        id:"satisfaction",
//			        hasAll:true
			        type:"plugin:satisfactionTool",
			        title:""+ JtalkManager_WebContent_bootstrapUI_js_running_application_dialogueManagement_js_46 +"",
			        placeholder:""+ JtalkManager_WebContent_bootstrapUI_js_running_application_dialogueManagement_js_47 +"",
			        selectType:true,
			        treeType:"satisfaction",
			        id:"satisfaction",
			        cls:"col-xs-12 col-sm-12 col-md-6"
			      },{
		          	type:"time",
		          	title:""+ JtalkManager_WebContent_bootstrapUI_js_running_application_dialogueManagement_js_48 +"",
		          	placeholder:""+ JtalkManager_WebContent_bootstrapUI_js_running_application_dialogueManagement_js_49 +"",
		          	picker:"dateTime",
		          	id:"startTime"
		          },{
		          	type:"time",
		          	title:""+ JtalkManager_WebContent_bootstrapUI_js_running_application_dialogueManagement_js_50 +"",
		          	placeholder:""+ JtalkManager_WebContent_bootstrapUI_js_running_application_dialogueManagement_js_51 +"",
		          	picker:"dateTime",
		          	id:"endTime"
		          },{
		            type:"plugin:inputCategoryTree",
		            placeholder:""+ JtalkManager_WebContent_bootstrapUI_js_running_application_dialogueManagement_js_52 +"",
		            title:""+ JtalkManager_WebContent_bootstrapUI_js_running_application_dialogueManagement_js_53 +"",
		            id:"inputCategoryTree"
		          },{
		          	type:"input",
		          	title:""+ JtalkManager_WebContent_bootstrapUI_js_running_application_dialogueManagement_js_54 +"",
		          	placeholder:""+ JtalkManager_WebContent_bootstrapUI_js_running_application_dialogueManagement_js_55 +"",
		          	id:"keyword"
		          },{
			        type:"input",
			        title:""+ JtalkManager_WebContent_bootstrapUI_js_running_application_dialogueManagement_js_56 +"",
			        placeholder:""+ JtalkManager_WebContent_bootstrapUI_js_running_application_dialogueManagement_js_57 +"",
			        id:"startChatDuration",
			        validation:{
						type:"number",
			        	"data-validation-number-message":""+ JtalkManager_WebContent_bootstrapUI_js_running_application_dialogueManagement_js_58 +"！"
			        }
			      },{
			        type:"input",
			        title:""+ JtalkManager_WebContent_bootstrapUI_js_running_application_dialogueManagement_js_59 +"",
			        placeholder:""+ JtalkManager_WebContent_bootstrapUI_js_running_application_dialogueManagement_js_60 +"",
			        id:"endChatDuration",
			        validation:{
						type:"number",
			        	"data-validation-number-message":""+ JtalkManager_WebContent_bootstrapUI_js_running_application_dialogueManagement_js_61 +"！"
			        }
			      },{
			        type:"plugin:normalTree",
			        title:""+ JtalkManager_WebContent_bootstrapUI_js_running_application_dialogueManagement_js_62 +"",
			        placeholder:""+ JtalkManager_WebContent_bootstrapUI_js_running_application_dialogueManagement_js_63 +"",
			        selectType:true,
			        treeType:"dep",
			        id:"bsTreepks"
			      },{
			        type:"select",
			        title:""+ JtalkManager_WebContent_bootstrapUI_js_running_application_dialogueManagement_js_64 +"",
			        placeholder:""+ JtalkManager_WebContent_bootstrapUI_js_running_application_dialogueManagement_js_65 +"",
			        id:"topicType",
			        option:{
			        	"text":""+ JtalkManager_WebContent_bootstrapUI_js_running_application_dialogueManagement_js_66 +"",
			        	"audio":""+ JtalkManager_WebContent_bootstrapUI_js_running_application_dialogueManagement_js_67 +"",
			        	"vedio":""+ JtalkManager_WebContent_bootstrapUI_js_running_application_dialogueManagement_js_68 +""
			        },
			        multiple:true
			      },{
			        type:"select",
			        title:""+ JtalkManager_WebContent_bootstrapUI_js_running_application_dialogueManagement_js_69 +"",
			        placeholder:""+ JtalkManager_WebContent_bootstrapUI_js_running_application_dialogueManagement_js_70 +"",
			        id:"voiceScore",
			        option:{
			        	"":""+ JtalkManager_WebContent_bootstrapUI_js_running_application_dialogueManagement_js_71 +"",
			        	"0":"0"+ JtalkManager_WebContent_bootstrapUI_js_running_application_dialogueManagement_js_72 +"",
			        	"1":"1"+ JtalkManager_WebContent_bootstrapUI_js_running_application_dialogueManagement_js_73 +"",
			        	"2":"2"+ JtalkManager_WebContent_bootstrapUI_js_running_application_dialogueManagement_js_74 +"",
			        	"3":"3"+ JtalkManager_WebContent_bootstrapUI_js_running_application_dialogueManagement_js_75 +"",
			        	"4":"4"+ JtalkManager_WebContent_bootstrapUI_js_running_application_dialogueManagement_js_76 +"",
			        	"5":"5"+ JtalkManager_WebContent_bootstrapUI_js_running_application_dialogueManagement_js_77 +""
			        },
			        multiple:false
			      },{
			        type:"select",
			        title:""+ JtalkManager_WebContent_bootstrapUI_js_running_application_dialogueManagement_js_78 +"",
			        placeholder:""+ JtalkManager_WebContent_bootstrapUI_js_running_application_dialogueManagement_js_79 +"",
			        id:"trench",
			        option:trenchOption,
			        multiple:false
			      },{
			        type:"select",
			        title:""+ JtalkManager_WebContent_bootstrapUI_js_running_application_dialogueManagement_js_89 +"",
			        placeholder:""+ JtalkManager_WebContent_bootstrapUI_js_running_application_dialogueManagement_js_90 +"",
			        id:"eventName",
			        option: eventNameOptions,
			        multiple:false
			      },{
		          	type:"input",
		          	title:""+ JtalkManager_WebContent_bootstrapUI_js_running_application_dialogueManagement_js_100 +"",
		          	placeholder:""+ JtalkManager_WebContent_bootstrapUI_js_running_application_dialogueManagement_js_101 +"",
		          	id:"eventTargetName",
		          },
                  {
                      type:"select",
                      title:"小结状态",
                      placeholder:"小结状态",
                      id:"iResultStatu",
                      option:{
                          "0":"全部",
                          "1":"是",
                          "2":"否"
                      },
                      multiple:true
                  },
                  {
                      type:"select",
                      title:"验证结果",
                      placeholder:"验证结果",
                      id:"verificationResults",
                      option:{
                          "0":"全部",
                          "1":"验证通过",
                          "2":"验证失败",
                          "3":"未验证"
                      },
                      multiple:true
                  }]
		        },{
		        	id:"dialogueManageTable",
		            target:".dialogueManageTable",
		            type:"table",
		            jsonUrl:"./dialogueManagement.do",
		            params:{
		           	    method : 'chatRecordGrid',
		           	    chatStartTime:startTimeStr,
						chatEndTime:endTimeStr
		            },
		            sortname:"requestTime",
		            sortorder:"desc",
		            btns:[{
		        	  btnClass:".export",
		  	            btnDiv: '<button class="btn btn-default export" type="button" >'+ JtalkManager_WebContent_bootstrapUI_js_running_application_dialogueManagement_js_102 +'</button>',
		  	            btnFun: function() {},
		  	            place:"front"
		            }],
			          format:[{
		                  title: ''+ JtalkManager_WebContent_bootstrapUI_js_running_application_dialogueManagement_js_103 +'',
		                  field: 'isqc',
		                  align: 'center',
		                  sortable: true,
		                  formatter:function(value, row, index) {
		                  	var msg = ""+ JtalkManager_WebContent_bootstrapUI_js_running_application_dialogueManagement_js_104 +"";
		          			if (value == 2) {
		          				msg = ""+ JtalkManager_WebContent_bootstrapUI_js_running_application_dialogueManagement_js_105 +"";
		          			}
		          	  		return msg ;
		      	  		}
		              },{
                          title: '小结状态',
                          field: 'iResultStatu',
                          align: 'center',
                          sortable: true,
                          formatter:function(value, row, index) {
                              var msg = ""+ JtalkManager_WebContent_bootstrapUI_js_running_application_dialogueManagement_js_105 +"";
                              if (value == 2) {
                                  msg = ""+ JtalkManager_WebContent_bootstrapUI_js_running_application_dialogueManagement_js_104 +"";
                              }
                              return msg ;
                          }
                      },{
		                  title: ''+ JtalkManager_WebContent_bootstrapUI_js_running_application_dialogueManagement_js_106 +'',
		                  field: 'replyMsg',
		                  align: 'center',
		                  sortable: true,
		                  formatter:function(value, row, index) {
		                	var nowtime = new Date().getTime();
		                	if(!!row.requestTime){
		                		var recordTime = row.requestTime.time;
		          				if(nowtime-recordTime<10*24*3600*1000&&row.trench==""+ JtalkManager_WebContent_bootstrapUI_js_running_application_dialogueManagement_js_107 +"" && row.chatEndTime ){
		          					var formatStr = "<input type='button'  class='btn btn-primary wxReply' value='"+ JtalkManager_WebContent_bootstrapUI_js_running_application_dialogueManagement_js_108 +"' />";
		          					return "<div class='controlBtn'>" + formatStr + "</div>";
		          				}else{
		          					return "";
		          				}
		            		}
		                	return "";
		          	  	}
		              },{
		                  title: ''+ JtalkManager_WebContent_bootstrapUI_js_running_application_dialogueManagement_js_109 +'',
		                  field: 'requestTime',
		                  align: 'center',
		                  sortable: true,
		                  formatter:function(value, row, index) {
		                	  if(value && value.time){
		                		  return "<div style='width:150px'>"+new Date(value.time).Format("yyyy-MM-dd hh:mm:ss")+"</div>";
		                	  }
		                  	return "<div style='width:150px'></div>";
		          	  	  }
		              },{
		                  title: ''+ JtalkManager_WebContent_bootstrapUI_js_running_application_dialogueManagement_js_110 +'ID',
		                  field: 'visitorId',
		                  align: 'center',
		                  sortable: true,
		                  'class': "visitorId"
		              },{
		                  title: ''+ JtalkManager_WebContent_bootstrapUI_js_running_application_dialogueManagement_js_111 +'',
		                  field: 'visitorName',
		                  align: 'center',
		                  sortable: true,
		                  'class':"name"
		              },{
		              	title: ''+ JtalkManager_WebContent_bootstrapUI_js_running_application_dialogueManagement_js_112 +'',
		                  field: 'departmentPk',
		                  align: 'center',
		                  sortable: true
		              },{
		              	  title: ''+ JtalkManager_WebContent_bootstrapUI_js_running_application_dialogueManagement_js_113 +'',
		                  field: 'fromTitle',
		                  align: 'center',
		                  sortable: true,
		                  formatter:function(value, row, index) {
		                	  var html = "<div style='width:150px'>";
		                  		if(value && !row.fromPage){
		                  			html += value
		                  		}else if(!value && row.fromPage){
		                  			html += "<a href='"+row.fromPage+"'>"+row.fromPage+"</a>"
		                  		}else if(value && row.fromPage ){
		                  			html += "<a href='"+row.fromPage+"'>"+value+"</a>"
		                  		}else{
		                  			html += "";
		                  		}
		                  		html +="</div>";
		                  		return html;
		            	  	}
		              },{
		              	title: ''+ JtalkManager_WebContent_bootstrapUI_js_running_application_dialogueManagement_js_114 +'',
		                  field: 'operatorPk',
		                  align: 'center',
		                  sortable: true,
		                  formatter:function(value, row, index) {
		                	
		                  	if (null != value && value != '' && null != operator[value]) {
		          				return operator[value].name;
		          			} else {
		          				return '';
		          			}
		          	  	}
		              },{
		                  title: ''+ JtalkManager_WebContent_bootstrapUI_js_running_application_dialogueManagement_js_115 +'',
		                  field: 'chatStartTime',
		                  align: 'center',
		                  sortable: true,
		                  formatter:function(value, row, index) {
		                	  if(value && value.time){
		                		  return "<div style='width:150px'>"+new Date(value.time).Format("yyyy-MM-dd hh:mm:ss")+"</div>";
		                	  }
		                  	return "<div style='width:150px'></div>";
		        	  	  }
		              },{
		                  title: ''+ JtalkManager_WebContent_bootstrapUI_js_running_application_dialogueManagement_js_116 +'',
		                  field: 'chatEndTime',
		                  align: 'center',
		                  sortable: true,
		                  formatter:function(value, row, index) {
		                	  if(value && value.time){
		                		  return "<div style='width:150px'>"+new Date(value.time).Format("yyyy-MM-dd hh:mm:ss")+"</div>";
		                	  }
		                  	return "<div style='width:150px'></div>";
		        	  	  }
		              },{
		                  title: ''+ JtalkManager_WebContent_bootstrapUI_js_running_application_dialogueManagement_js_117 +'',
		                  field: 'chatDuration',
		                  align: 'center',
		                  sortable: true,
		                  formatter:function(value, row, index) {
		        			if (null == value || '' == value) {
		        				return "<div style='width:150px'></div>";
		        			}
		        			var second = value % 60;
		        			var min = parseInt(value / 60);
		        			var hour = parseInt(min / 60);
		        			var minutes = min % 60;
		        			if (hour < 10) {
		        				hour = "0" + hour;
		        			}
		        			if (minutes < 10) {
		        				minutes = "0" + minutes;
		        			}
		        			if (second < 10) {
		        				second = "0" + second;
		        			}
		        			var time = hour + ''+ JtalkManager_WebContent_bootstrapUI_js_running_application_dialogueManagement_js_118 +'' + minutes + ''+ JtalkManager_WebContent_bootstrapUI_js_running_application_dialogueManagement_js_119 +'' + second + ''+ JtalkManager_WebContent_bootstrapUI_js_running_application_dialogueManagement_js_120 +'';
		        			return time;
		        			return "<div style='width:150px'>"+time+"</div>";
			    	  	  }
		              },{
		                  title: ''+ JtalkManager_WebContent_bootstrapUI_js_running_application_dialogueManagement_js_121 +'',
		                  field: 'topicNames',
		                  align: 'center',
		                  'class':"topicNames",
		                  sortable: true,
		                  formatter:function(value, row, index) {
		                	if(value){
		      					value=value.replace(/^;{1}|^；{1}/g,'');//去掉分号
		      					value=value.replaceAll(',',"->")
		      				}
		      				return value;
		          		}
		              },{
		                  title: ''+ JtalkManager_WebContent_bootstrapUI_js_running_application_dialogueManagement_js_122 +'',
		                  field: 'topicType',
		                  align: 'center',
		                  sortable: true,
		                  formatter:function(value, row, index) {
		                  	var msg = "";
		          			if (value == "audio") {
		          				msg = "<span style = 'color:green'>"+ JtalkManager_WebContent_bootstrapUI_js_running_application_dialogueManagement_js_123 +"</span>";
		          			}else if(value == "vedio"){
		          				msg = "<span style = 'color:green'>"+ JtalkManager_WebContent_bootstrapUI_js_running_application_dialogueManagement_js_124 +"</span>";
		          			}else{
		          				msg = ""+ JtalkManager_WebContent_bootstrapUI_js_running_application_dialogueManagement_js_125 +"";
		          			}
		          			return msg;
		          		}
		              },{
		            	  title : ''+ JtalkManager_WebContent_bootstrapUI_js_running_application_dialogueManagement_js_126 +'',
		            	  field : 'score',
		            	  sortable : true,
		            	  align : 'center'
		    		  },{
		            	  title : ''+ JtalkManager_WebContent_bootstrapUI_js_running_application_dialogueManagement_js_127 +'',
		            	  field : 'scoreName',
		            	  sortable : true,
		            	  align : 'center',
		                  formatter:function(value, row, index) {
		                    	if (null != value && value != '' && null != operator[value]) {
		            				return operator[value].userName.substring(operator[value].userName.indexOf("-")+1);
		            			} else {
		            				return '';
		            			}
		            	  	}
		    		  }, {
		    			  title : ''+ JtalkManager_WebContent_bootstrapUI_js_running_application_dialogueManagement_js_128 +'',
		    			  field : 'optionPk',
		    				sortable : true,
		    				align : 'center',
		    				formatter : function(v, row, index) {
		    					if(!satisfactions){
		    						return '';
		    					}
		    					var satisfaction = eval("("+satisfactions+")");
		    					if (null != v && v != '') {
		    						if (null != satisfaction[v] && satisfaction[v] != '') {
		    							return satisfaction[v].name;
		    						}else{
		    							return '';
		    						}
		    					} else {
		    						return '';
		    					}
		
		    				}
		    			},{
		                  title: ''+ JtalkManager_WebContent_bootstrapUI_js_running_application_dialogueManagement_js_129 +'',
		                  field: 'nextSatisfactionPk',
		                  align: 'center',
		                  sortable: true,
		                  formatter:function(v, row, index) {
		                	  if(!satisfactions){
		  						return '';
		  					}
		                	  var satisfaction = eval("("+satisfactions+")");
		                	  if (null != v && v != '') {
		      					if(v.indexOf(",")>0){
		      						var nextsta = v.split(",");
		      						for (var int = 0; int < nextsta.length; int++) {
		      							v = v.replace(nextsta[int],satisfaction[nextsta[int]].name);
		      						}
		      						return v;
		      					}else{
		      						return satisfaction[v].name;
		      					}
		      				} else {
		      					return '';
		      				}
		          		}
		              },{
		            	  title : ''+ JtalkManager_WebContent_bootstrapUI_js_running_application_dialogueManagement_js_130 +'',
		            	  field : 'satisfactionMemo',
		    			sortable : true,
		    			align : 'center'
		    		  },{
		                  title: ''+ JtalkManager_WebContent_bootstrapUI_js_running_application_dialogueManagement_js_131 +'',
		                  field: 'voiceScore',
		                  align: 'center',
		                  sortable: true
		              },{
		                  title: ''+ JtalkManager_WebContent_bootstrapUI_js_running_application_dialogueManagement_js_132 +'',
		                  field: 'trench',
		                  align: 'center',
		                  sortable: true
		              },{
		                  title: ''+ JtalkManager_WebContent_bootstrapUI_js_running_application_dialogueManagement_js_133 +'',
		                  field: 'eventName',
		                  align: 'center',
		                  sortable: true,
		                  formatter:function(value, row, index) {
		                	  return "<div style='width:150px'>"+checkRow(row).event+"</div>";
		          	  	  }
		              },{
		                  title: ''+ JtalkManager_WebContent_bootstrapUI_js_running_application_dialogueManagement_js_134 +'',
		                  field: 'eventTargetName',
		                  align: 'center',
		                  sortable: true,
		                  formatter:function(value, row, index) {
		                	  return "<div style='width:150px'>"+checkRow(row).target+"</div>";
		          	  	  }
		              },{
                          title: '排队时长',
                          field: 'queueTime',
                          align: 'center',
                          sortable: true,
                          formatter:function(value, row, index) {
                              if (null == value || '' == value) {
                                  return "<div style='width:150px'>0</div>";
                              }
                              var second = value % 60;
                              var min = parseInt(value / 60);
                              var hour = parseInt(min / 60);
                              var minutes = min % 60;
                              if (hour < 10) {
                                  hour = "0" + hour;
                              }
                              if (minutes < 10) {
                                  minutes = "0" + minutes;
                              }
                              if (second < 10) {
                                  second = "0" + second;
                              }
                              var time = "";
                              if(hour==0 && minutes==0&& second==0){
                                  time = "0";
                              }else{
                                  time =hour+":"+minutes+":"+second;
                              }
                              return time;
                              return "<div style='width:150px'>" + time + "</div>";
                           }
                          }, {
		                  //title: '对话结束方式',
		                  title: ''+ JtalkManager_WebContent_bootstrapUI_js_running_application_dialogueManagement_js_197 +'',
		                  field: 'leaveType',		
		                  align: 'center',
		                  sortable: true,
		                  formatter:function(value, row, index) {
		                	  if(row.chatEndTime){
		                		  if(value=="customer_network_leave" || value=="operatorLeaving" || value=="system"){
		                			if(null!=$(".selections #settingtime").getVisibleValue() && '' !=$(".selections #settingtime").getVisibleValue() && $(".selections #settingtime").getVisibleValue()<=row.chatDuration  )
		                				//return "<div style='color:red;'>坐席主动</div>";
		                				return "<div style='color:red;'>"+JtalkManager_WebContent_bootstrapUI_js_running_application_dialogueManagement_js_198+"</div>";
		                			else
		                				//return "坐席主动";
		                				return ""+JtalkManager_WebContent_bootstrapUI_js_running_application_dialogueManagement_js_198+"";
		                      	  }else if(value=="visitor_leave" || value=="visitor_timeout_leave" || value=="visitor_close_browser"){
		                      		if(null!=$(".selections #settingtime").getVisibleValue() && '' !=$(".selections #settingtime").getVisibleValue() && $(".selections #settingtime").getVisibleValue()<=row.chatDuration  )
		                				//return "<div style='color:red;'>访客主动</div>";
		                      			return "<div style='color:red;'>"+JtalkManager_WebContent_bootstrapUI_js_running_application_dialogueManagement_js_199+"</div>";
		                			else
		                      		   // return "访客主动";
		                				return ""+JtalkManager_WebContent_bootstrapUI_js_running_application_dialogueManagement_js_199+"";
		                      	  }else {
		                      		if(null!=$(".selections #settingtime").getVisibleValue() && '' !=$(".selections #settingtime").getVisibleValue() && $(".selections #settingtime").getVisibleValue()<=row.chatDuration  )
		                				//return "<div style='color:red;'>系统中断</div>";
		                      			return "<div style='color:red;'>"+JtalkManager_WebContent_bootstrapUI_js_running_application_dialogueManagement_js_200+"</div>";
		                			else
		                      		   // return "系统中断";
		                				return ""+JtalkManager_WebContent_bootstrapUI_js_running_application_dialogueManagement_js_200+"";
		                      	  }
		                	  }else{
		                		  if(null!=$(".selections #settingtime").getVisibleValue() && '' !=$(".selections #settingtime").getVisibleValue() && $(".selections #settingtime").getVisibleValue()<=row.chatDuration  )
		                			  //return "<div style='color:red;'>系统中断</div>";
		                			  return "<div style='color:red;'>"+JtalkManager_WebContent_bootstrapUI_js_running_application_dialogueManagement_js_200+"</div>";
		                		  else
		                			 // return "系统中断";
		                			  return ""+JtalkManager_WebContent_bootstrapUI_js_running_application_dialogueManagement_js_200+"";
		                	  }
		        	  	  }
		              },{
                          title: '验证结果',
                          field: 'verificationResults',
                          align: 'center',
                          sortable: true,
                          formatter:function(value, row, index) {
                              var msg = "";
                              if (value == 1) {
                                  msg = "验证通过";
                              }else if(value == 2){
                                  msg = "验证失败";
                              }else{
                                  msg = "未验证";
                              }
                              return msg ;
                          }
                      }
		              ]
				},{
		          	type:"plugin:popOut",
		          	target:"#dialogueManagement",
		          	id:"popOut"
	            },{
	            	type:"modal",
	            	target:"#dialogueManagement",
	            	id:"qcModal",
	            	title:""+ JtalkManager_WebContent_bootstrapUI_js_running_application_dialogueManagement_js_135 +"",
	  	            body:"<form class='qcModalBody'></form>",
	  	            footer:'<button type="button" class="btn btn-primary qd">'+ JtalkManager_WebContent_bootstrapUI_js_running_application_dialogueManagement_js_136 +'</button><button type="button" class="btn btn-default" data-dismiss="modal">'+ JtalkManager_WebContent_bootstrapUI_js_running_application_dialogueManagement_js_137 +'</button>'
	            },{
	            	type:"input",
					target:".qcModalBody",
					placeholder:""+ JtalkManager_WebContent_bootstrapUI_js_running_application_dialogueManagement_js_138 +"",
					title:""+ JtalkManager_WebContent_bootstrapUI_js_running_application_dialogueManagement_js_139 +"",
	            	validation:{
	            		pattern:'^([0-9]|[1-9][0-9]|100)$',
		            	'data-validation-pattern-message':'0-100'+ JtalkManager_WebContent_bootstrapUI_js_running_application_dialogueManagement_js_140 +''
	            	},
	            	cls:"score"
	            },{
	            	type:"label",
					target:".qcModalBody",
					placeholder:userName,
					title:""+ JtalkManager_WebContent_bootstrapUI_js_running_application_dialogueManagement_js_141 +""
	            },{
	            	type:"modal",
	            	target:"#dialogueManagement",
	            	id:"remarkModal",
	            	title:""+ JtalkManager_WebContent_bootstrapUI_js_running_application_dialogueManagement_js_142 +"",
	            	body:"<form class='remarkModalBody'></form>",
	            	footer:'<button type="button" class="btn btn-primary qd">'+ JtalkManager_WebContent_bootstrapUI_js_running_application_dialogueManagement_js_143 +'</button><button type="button" class="btn btn-default" data-dismiss="modal">'+ JtalkManager_WebContent_bootstrapUI_js_running_application_dialogueManagement_js_144 +'</button>'
	            },{
	            	type:"textarea",
					target:".remarkModalBody",
					placeholder:""+ JtalkManager_WebContent_bootstrapUI_js_running_application_dialogueManagement_js_145 +"500"+ JtalkManager_WebContent_bootstrapUI_js_running_application_dialogueManagement_js_146 +"",
					title:""+ JtalkManager_WebContent_bootstrapUI_js_running_application_dialogueManagement_js_147 +"",
	            	validation:{
	            		pattern:'([\\s\\S]){0,500}',
		            	'data-validation-pattern-message':''+ JtalkManager_WebContent_bootstrapUI_js_running_application_dialogueManagement_js_148 +'500'+ JtalkManager_WebContent_bootstrapUI_js_running_application_dialogueManagement_js_149 +''
	            	},
	            	cls:"remark"
	            },{
	            	type:"modal",
	            	target:"#dialogueManagement",
	            	id:"wxReplyModal",
	            	title:""+ JtalkManager_WebContent_bootstrapUI_js_running_application_dialogueManagement_js_150 +"",
	            	body:"<form class='wxReplyModalBody'></form>",
	            	footer:'<button type="button" class="btn btn-primary qd">'+ JtalkManager_WebContent_bootstrapUI_js_running_application_dialogueManagement_js_151 +'</button><button type="button" class="btn btn-default" data-dismiss="modal">'+ JtalkManager_WebContent_bootstrapUI_js_running_application_dialogueManagement_js_152 +'</button>'
	            },{
	            	type:"label",
					target:".wxReplyModalBody",
					title:""+ JtalkManager_WebContent_bootstrapUI_js_running_application_dialogueManagement_js_153 +"",
					cls:"wxReplyLabel"
	            },{
	            	type:"textarea",
					target:".wxReplyModalBody",
					placeholder:""+ JtalkManager_WebContent_bootstrapUI_js_running_application_dialogueManagement_js_154 +"500"+ JtalkManager_WebContent_bootstrapUI_js_running_application_dialogueManagement_js_155 +"",
					title:""+ JtalkManager_WebContent_bootstrapUI_js_running_application_dialogueManagement_js_156 +"",
	            	validation:{
	            		pattern:'([\\s\\S]){0,500}',
		            	'data-validation-pattern-message':''+ JtalkManager_WebContent_bootstrapUI_js_running_application_dialogueManagement_js_157 +'500'+ JtalkManager_WebContent_bootstrapUI_js_running_application_dialogueManagement_js_158 +'',
		            	required:true,
		            	'data-validation-required-message':''+ JtalkManager_WebContent_bootstrapUI_js_running_application_dialogueManagement_js_159 +''
	            	},
	            	cls:"wxReplyTextarea"
	            }]
		}).start().done(function(main){
			var selectedPk = "";
			$("#startTime").setValue(startTimeStr);
			$("#endTime").setValue(endTimeStr);
			$("#popOut .popContent").html(popHtml);
			main.multipleCreate([{
				type:"plugin:categoryTree",
				target:"#popOut .popContent .categoryBox",
				placeholder:""+ JtalkManager_WebContent_bootstrapUI_js_running_application_dialogueManagement_js_160 +"",
				title:""+ JtalkManager_WebContent_bootstrapUI_js_running_application_dialogueManagement_js_161 +"",
				cls:"popCategoryTree"
			},{
				type:"select",
				target:"#popOut .popContent .categoryBox",
				placeholder:"图文交互",
				title:"图文交互",
				option:{
		        	"请选择":"请选择",
		        	"全文本信息":"全文本信息",
		        	"接受客户的图片/语音/视频等非文本信息":"接受客户的图片/语音/视频等非文本信息",
		        	"发送图片/截图等非文本信息":"发送图片/截图等非文本信息"
		        },
				cls:"popCategorySelect"
			},{
				type:"textarea",
				target:"#popOut .popContent .categoryBox",
				placeholder:""+ JtalkManager_WebContent_bootstrapUI_js_running_application_dialogueManagement_js_162 +"255"+ JtalkManager_WebContent_bootstrapUI_js_running_application_dialogueManagement_js_163 +"",
				title:""+ JtalkManager_WebContent_bootstrapUI_js_running_application_dialogueManagement_js_164 +"",
				validation:{
					pattern:"([\\s\\S]){0,255}",
					"data-validation-pattern-message":""+ JtalkManager_WebContent_bootstrapUI_js_running_application_dialogueManagement_js_165 +"255"+ JtalkManager_WebContent_bootstrapUI_js_running_application_dialogueManagement_js_166 +""
				},
				cls:"popCategoryTextarea"
			},{
				type:"label",
				target:"#popOut .popContent .chatInfo",
				placeholder:"",
				//title:"结束方式",
				title:""+ JtalkManager_WebContent_bootstrapUI_js_running_application_dialogueManagement_js_195 +"",
				cls:"popLeave"
			},{
				type:"label",
				target:"#popOut .popContent .chatInfo",
				placeholder:"",
				//title:"结束时间",
				title:""+ JtalkManager_WebContent_bootstrapUI_js_running_application_dialogueManagement_js_196 +"",
				cls:"popLeaveTime"
			},{
				type:"label",
				target:"#popOut .popContent .visitorBox",
				placeholder:"",
				title:""+ JtalkManager_WebContent_bootstrapUI_js_running_application_dialogueManagement_js_167 +"ID",
				cls:"popVisitorId"
			},{
				type:"label",
				target:"#popOut .popContent .visitorBox",
				placeholder:"",
				title:""+ JtalkManager_WebContent_bootstrapUI_js_running_application_dialogueManagement_js_168 +"",
				cls:"popVisitorName"
			},{
				type:"label",
				target:"#popOut .popContent .visitorBox",
				placeholder:"",
				title:""+ JtalkManager_WebContent_bootstrapUI_js_running_application_dialogueManagement_js_169 +"",
				cls:"popFromPage"
			},{
				type:"label",
				target:"#popOut .popContent .visitorBox",
				placeholder:"",
				title:"IP"+ JtalkManager_WebContent_bootstrapUI_js_running_application_dialogueManagement_js_170 +"",
				cls:"popIP"
			},{
				type:"label",
				target:"#popOut .popContent .visitorBox",
				placeholder:"",
				title:""+ JtalkManager_WebContent_bootstrapUI_js_running_application_dialogueManagement_js_171 +"",
				cls:"popSearch"
			},{
				type:"label",
				target:"#popOut .popContent .visitorBox",
				placeholder:"",
				title:""+ JtalkManager_WebContent_bootstrapUI_js_running_application_dialogueManagement_js_172 +"",
				cls:"popCity"
			},{
				type:"label",
				target:"#popOut .popContent .visitorBox",
				placeholder:"",
				title:""+ JtalkManager_WebContent_bootstrapUI_js_running_application_dialogueManagement_js_173 +"",
                cls:"popKeyword"
			},{
				type:"label",
				target:"#popOut .popContent .infoBox",
				placeholder:"",
				//title:""+ JtalkManager_WebContent_bootstrapUI_js_running_application_dialogueManagement_js_174 +"",
                title:'用户姓名',
				cls:"popRealName"
			},{
				type:"label",
				target:"#popOut .popContent .infoBox",
				placeholder:"",
				//title:""+ JtalkManager_WebContent_bootstrapUI_js_running_application_dialogueManagement_js_175 +"",
                title:'客户号',
				cls:"popVisitorId"
			},{
				type:"label",
				target:"#popOut .popContent .infoBox",
				placeholder:"",
				//title:""+ JtalkManager_WebContent_bootstrapUI_js_running_application_dialogueManagement_js_176 +"",
                title:'账号级别',
				cls:"popUserTier"
			},{
				type:"label",
				target:"#popOut .popContent .infoBox",
				placeholder:"",
				//title:""+ JtalkManager_WebContent_bootstrapUI_js_running_application_dialogueManagement_js_177 +"",
                title:'手机号码',
				cls:"popMobile"
			},{
				type:"label",
				target:"#popOut .popContent .infoBox",
				placeholder:"",
				//title:""+ JtalkManager_WebContent_bootstrapUI_js_running_application_dialogueManagement_js_178 +"ID",
                title:'是否登录',
				cls:"popIsLogin"
			},{
				type:"label",
				target:"#popOut .popContent .infoBox",
				placeholder:"",
				//title:""+ JtalkManager_WebContent_bootstrapUI_js_running_application_dialogueManagement_js_179 +"",
                title:'验证结果',
                cls:"popExtension"
			}
			// ,{
			// 	type:"label",
			// 	target:"#popOut .popContent .infoBox",
			// 	placeholder:"",
			// 	title:""+ JtalkManager_WebContent_bootstrapUI_js_running_application_dialogueManagement_js_180 +"",
			// 	cls:"popCompany"
			// }
			]);
			$('.dialogue_window').delegate('.dialogue_box .box img', 'click', function() {
				var src =  $(this).attr("originsrc") || $(this).attr("src");
	            if(src.indexOf("emotions") <0) showBigImgFun.showPic(src);
	        });
			$(".selections").delegate(".search",'click', function(event) {
				if(!!$("#startTime").getVisibleValue() && !!$("#endTime").getVisibleValue() && $("#startTime").getVisibleValue()>$("#endTime").getVisibleValue()){
					main.msg({id:"search",type:"error",message:""+ JtalkManager_WebContent_bootstrapUI_js_running_application_dialogueManagement_js_181 +"",hideAfter:3});
					return;
				}
				$("#dialogueManageTable").ncMethod("refresh",{params:{
					method : 'chatRecordGrid',
					satisfactionPk:$(".selections #satisfaction .ncsatisfactionToolType").getVisibleValue(),
					optionPk:$(".selections #satisfaction .ncsatisfactionToolOption").getVisibleValue(),
					operatorName:$(".selections #operatorAccount").getVisibleValue()?$(".selections #operatorAccount").getVisibleValue().key:"",
					visitorName:$(".selections #nickName").getVisibleValue(),
					chatStartTime:$(".selections #startTime").getVisibleValue(),
					chatEndTime:$(".selections #endTime").getVisibleValue(),
					context:$(".selections #keyword").getVisibleValue(),
					startChatDuration:$(".selections #startChatDuration").getVisibleValue(),
					endChatDuration:$(".selections #endChatDuration").getVisibleValue(),
					bsTreepks:$(".selections #bsTreepks").getVisibleValue().key || '',
					topicType:$(".selections #topicType").getVisibleValue().key || '',
					voiceScore:$(".selections #voiceScore").getVisibleValue().key || '',
					trench:$(".selections #trench").getVisibleValue().key || '',
					eventName:$(".selections #eventName").getVisibleValue().key || '',
					eventTargetName:$(".selections #eventTargetName").getVisibleValue(),
					topicPk:$("#inputCategoryTree").getVisibleValue().key.replace(/;/g, ',').replace(/\|/g, ',') || '',
                    iResultStatu:$(".selections #iResultStatu").getVisibleValue().key||'',
                    verificationResults:$(".selections #verificationResults").getVisibleValue().key||0
				}})
			});
			$(".selections").delegate(".reset",'click', function(event) {
				$(".selections .opList>div").clearValue();
				$(".selections .search").click();
				$(".selections .topOptions").clearValue();
			});	
			$("body").delegate(".export","click",function(){
		    	$.ajax({
		    		url:"./dialogueManagement.do",
	    			data:{
	    				method:"excelChatRecordGrid",
	    				satisfactionPk:$(".selections #satisfaction .ncsatisfactionToolType").getVisibleValue(),
	    				optionPk:$(".selections #satisfaction .ncsatisfactionToolOption").getVisibleValue(),
						operatorName:$(".selections #operatorAccount").getVisibleValue()?$(".selections #operatorAccount").getVisibleValue().key:"",
						visitorName:$(".selections #nickName").getVisibleValue(),
						chatStartTime:$(".selections #startTime").getVisibleValue(),
						chatEndTime:$(".selections #endTime").getVisibleValue(),
						context:$(".selections #keyword").getVisibleValue(),
						startChatDuration:$(".selections #startChatDuration").getVisibleValue(),
						endChatDuration:$(".selections #endChatDuration").getVisibleValue(),
						bsTreepks:$(".selections #bsTreepks").getVisibleValue().key|| '',
						topicType:$(".selections #topicType").getVisibleValue().key|| '',
						voiceScore:$(".selections #voiceScore").getVisibleValue().key|| '',
						trench:$(".selections #trench").getVisibleValue().key|| '',
						eventName:$(".selections #eventName").getVisibleValue().key|| '',
						eventTargetName:$(".selections #eventTargetName").getVisibleValue(),
						topicPk:$("#inputCategoryTree").getVisibleValue().key.replace(/;/g, ',').replace(/\|/g, ',') || '',
                        iResultStatu:$(".selections #iResultStatu").getVisibleValue().key||'',
                        verificationResults:$(".selections #verificationResults").getVisibleValue().key||0
                    },
					dataType:"json",
					type:"POST",
					async:true
				}).done(function(data){
					if (data.success == false) {
						main.msg({id:"search",type:"error",message:data.msg,hideAfter:2});
					} else {
                        var url = ""+data.toUrl;//地址错误需要修改后台
                        try {
                            //如果成功，使用form表单进行下载
                            var form=$("<form>");//定义一个form表单
                            form.attr("style","display:none");
                            form.attr("target","");
                            form.attr("method","post");
                            form.attr("action","./dialogueManagement.do");
                            var input1=$("<input>");
                            input1.attr("type","hidden");
                            input1.attr("name","method");
                            input1.attr("value","downloadByForm");
                            var input2=$("<input>");
                            input2.attr("type","hidden");
                            input2.attr("name","filePath");
                            input2.attr("value",url);
                            $("body").append(form);//将表单放置在web中
                            form.append(input1).append(input2);
                            form.submit();//表单提交
                        } catch(e) {}
					}
				}).fail(function(){
					main.msg({id:"search",type:"error",message:""+ JtalkManager_WebContent_bootstrapUI_js_running_application_dialogueManagement_js_182 +"",hideAfter:2});
				});
			});
			var getVisitorInfo = function(id,verificationResults){
				var el = {};
				$.ajax({type:"POST",url: "./dialogueManagement.do",data:{method:"getVisitorInfo",memberId:id}, dataType:"json",async:false})
				.done(function(e){
                    el.popRealName = e.nickName;
                    el.popVisitorId = e.visitorId;
                    el.popUserTier = e.userTier;
                    el.popIsLogin = e.phone;
                    el.popMobile = e.mobilePhone;
                    //el.popExtension = e.exegesis;
                    if(verificationResults == 1){
                        el.popExtension = "身份验证成功";
                    }else if(verificationResults == 2){
                        el.popExtension = "身份验证失败";
                    }else{
                        el.popExtension = "未验证";
                    }
                    verificationResults = 3;
                    // el.popVisitorName=e.nickName;
					// el.popFromPage=e.trench;
					// el.popIP=e.insertIp;
					// el.popNickName=e.nickName;
					// el.popName=e.name;
					// if(e.gender=="0"){
					// 	el.popSex=""+ JtalkManager_WebContent_bootstrapUI_js_running_application_dialogueManagement_js_183 +"";
					// }else if(e.gender=="1"){
					// 	el.popSex=""+ JtalkManager_WebContent_bootstrapUI_js_running_application_dialogueManagement_js_184 +"";
					// }else if(e.gender=="2"){
					// 	el.popSex=""+ JtalkManager_WebContent_bootstrapUI_js_running_application_dialogueManagement_js_185 +"";
					// }
					// el.popLevel=e.userTier;
					// el.popPhone=e.mobilePhone;
					// el.popCompany=e.companyName;
				})
				return el;
			}
			var getDialogueContent =  function(pk,memo){
				$.ajax({url: "./dialogueManagement.do",data:{method:"chatContentBychatRecordPk",chatRecordPk:pk}, dataType:"json"})
				.done(function(e){
                    verificationResults = e.verificationResults;
					var dias = $("<div>"+(e.msgContent?e.msgContent:"")+"</div>").find(".sevice_chat,.me_chat,.robot_chat");
					var diaStr = "";
		            var diaContent = "";
		            var ap = {};
		            var apsort = [];
		            for(var d = 0;d<dias.length;d++){
		                var sender = $(dias[d]).find("sender").html();
		                var time = $(dias[d]).find("time").html();
		                time = time.substring(11,19);
		                var html = "";
		                var content = $(dias[d]).find("content").html();
	                	content = changeFace.icoToImg(content);
	                	content = messageChange(content); 
		                var isback = !!$(dias[d]).find(".msg_back_success").html()?"<span>"+ JtalkManager_WebContent_bootstrapUI_js_running_application_dialogueManagement_js_186 +"</span>":"";
		                var from = !!$(dias[d]).hasClass("sevice_chat")?"client":!!$(dias[d]).hasClass("robot_chat")?"robot":"visitor";
		                html += $.timeStr.replace(/\$1/g, time);
		                html += $.messageStr.replace(/\$1/g, from).replace(/\$4/g, sender).replace(/\$3/g, "").replace(/\$2/g, content).replace(/\$back/g, isback);
		                ap[d] = html;
		                apsort.push({time:time,d:d});
		            }
		            apsort = keySort(apsort,keysrt('time',false));
		            //apsort.sort(keysrt('time',false));
		            for(var i=0,len=apsort.length;i<len;i++ ){
		            	diaContent+=ap[apsort[i].d];
		            }
		            if(diaContent==""){
		            	diaContent = '<div class="historyDialoguePic"><img src="./bootstrapUI/any800/images/dialogueNoRecorde.png"  ><span>'+ JtalkManager_WebContent_bootstrapUI_js_running_application_dialogueManagement_js_187 +'</span></div>'
		            }
		            diaContent += memo?"<div class='dialogue_box clearfix'>"+ JtalkManager_WebContent_bootstrapUI_js_running_application_dialogueManagement_js_188 +":"+memo:"</div>";
		            $(".dialogue_window").html(diaContent);
		            $(".dialogue_window [name='faceIco']").css("width","28px");
		            $("audio").each(function(index, el) {
		                if (!$(el).parent().hasClass('audiojs')) {
		                  $this = $(this);
		                  audiojs.helpers.whenError = function() {
		                    var placeholder = $(".dialogue-c").find("a[placeholder]")
		                    placeholder.html(""+ JtalkManager_WebContent_bootstrapUI_js_running_application_dialogueManagement_js_189 +"");
		                  }
		                  audiojs.create($this);
		                }
		              });
				})
			}
			$("body").delegate("#dialogueManageTable tbody tr[data-index]","click",function(el){
				var $this= $(this);
				$("#dialogueManageTable tbody tr").removeClass("active");
				$this.addClass("active");
				var index = $this.data("index");
				var item = $("#dialogueManageTable").getValue()[index];
				selectedPk = item.pk;
				getDialogueContent(selectedPk,item.memo);
				$(".wxReplyModalBody .wxReplyLabel").setValue(item.visitorName);
				$(".wxReplyModalBody .wxReplyTextarea").setValue("");
				$(".qcModalBody .score").setValue(item.score);
				$(".remarkModalBody .remark").setValue(item.memo);
				$(".popCategoryTextarea").setValue(item.topicMemo);
				$(".popCategorySelect").setValue(item.graphicType == null ? "请选择" : item.graphicType);
				$(".popCategoryTree").setValue(item.topicPks?item.topicPks:"");
				var title =item.fromTitle;
				var source = item.fromPage;
				var el = {
						popVisitorId:item.visitorId,
						popVisitorName:item.visitorName,
						popFromPage:"",
						popIP:"",
						popSearch:"",
						popCity:item.visitorIpName,
						popKeyword:"",
						popName:item.visitorName,
						popSex:""+ JtalkManager_WebContent_bootstrapUI_js_running_application_dialogueManagement_js_190 +"",
						popNickName:"",
						popLevel:"",
						popClientId:item.visitorId,
						popPhone:"",
						popCompany:""
				}
				var visitorInfo = getVisitorInfo(item.visitorId,item.verificationResults);
				el = $.extend({}, el, visitorInfo);
				var leaveType = ''
					if(item.leaveType=="customer_network_leave" || item.leaveType=="operatorLeaving" || item.leaveType=="system"){
	        				leaveType = ""+ JtalkManager_WebContent_bootstrapUI_js_running_application_dialogueManagement_js_198 +"";
	              	  }else if(item.leaveType=="visitor_leave" || item.leaveType=="visitor_timeout_leave" || item.leaveType=="visitor_close_browser"){
	              		
	        				leaveType =""+ JtalkManager_WebContent_bootstrapUI_js_running_application_dialogueManagement_js_199 +"";
	              	  }else {
	        				leaveType =""+ JtalkManager_WebContent_bootstrapUI_js_running_application_dialogueManagement_js_200 +"";
	              	  }
					$("#popOut .popContent .popLeave").setValue(leaveType);
					var chatEndTime = ''
					if (item.chatEndTime) {
						chatEndTime = new Date(item.chatEndTime.time).Format("yyyy-MM-dd hh:mm:ss")
					}
					$("#popOut .popContent .popLeaveTime").setValue(chatEndTime);
				if(title && !source){
					el.popFromPage =title;
          		}else if(!title && source){
          			el.popFromPage ="<a href='"+source+"'>"+source+"</a>"
          		}else if(title && source ){
          			el.popFromPage ="<a href='"+source+"'>"+title+"</a>"
          		}
				for(var i in el){
					$("#popOut .popContent ." + i).setValue(el[i]);
				}
				$("#popOut").popOut();
			})
			$(".saveCategory").on("click",function(){
				var list = $.validationCheck([".categoryBox > div"])
				if(list.success==true && list.list.length>0){
					main.msg({type:"error",id:"topicFunctionType",message:list.list[0],hideAfter:2});
					return false;
				}
				var val = $(".popCategoryTree").getValue();
				if(val==""){
					main.msg({type:"error",id:"topicFunctionType",message:""+ JtalkManager_WebContent_bootstrapUI_js_running_application_dialogueManagement_js_191 +"",hideAfter:2});
					return false;
				}
				if(selectedPk==""){
					main.msg({type:"error",id:"topicFunctionType",message:""+ JtalkManager_WebContent_bootstrapUI_js_running_application_dialogueManagement_js_192 +"",hideAfter:2});
					return false;
				}
				var pks = val.key.replace(new RegExp("\\;","gm"),"," ).replace(new RegExp("\\|","gm"),";" );
				var names = val.value.replace(new RegExp("\\;","gm"),"," ).replace(new RegExp("\\|","gm"),";" );
				var graphicType = $(".popCategorySelect").getValue().value;
				$.ajax({type:"POST",url: "./dialogueManagement.do",data:{method:"addRecordTopic",pk:selectedPk,topicMemo:$(".popCategoryTextarea").getValue(),treeids :pks,treeNames :names,graphicType:graphicType},dataType:"json"})
				.done(function(e){
					main.msg({id:"category",message:e.msg,hideAfter:2});
					$(".selections .search").click();
				})
			});
			/*$("#popOut .popContent .dialogue_window").delegate("a","click",function(el){
				if ($(this).attr("href")!="") {
					var url = $(this).attr("href");
					if (typeof(window.openUrl) == "undefined") {
						window.open(url);
				    } else {
				        try {
				        	window.openUrl(url);
				        } catch(e) {}
				    }
			    }
			});*/
			$(".all_col .tools .glyphicon-info-sign").parent().on('click', function(event) {
				$("#remarkModal").modalShow();
			});
			
			$(".all_col .tools .glyphicon-eye-open").parent().on('click', function(event) {
			    $("#qcModal").modalShow();
			});
			$(".all_col .tools .glyphicon-log-out").parent().on("click",function(){
				$.ajax({url: "./dialogueManagement.do",data:{method:"excelChatRecord",pk:selectedPk}})
				.done(function(data){
					main.msg({id:"exportExcel",message:""+ JtalkManager_WebContent_bootstrapUI_js_running_application_dialogueManagement_js_193 +"",hideAfter:2});
					// if (typeof (window.download) == "undefined") {
					// 	window.open(url);
					// } else {
					// 	try {
					// 		var baseurl = document.location.protocol+"//"+location.host + url;
					// 		window.download(baseurl);
					// 	} catch (e) {
					// 	}
					// }
                    var url = ""+data;//地址错误需要修改后台
                    try {
                        //如果成功，使用form表单进行下载
                        var form=$("<form>");//定义一个form表单
                        form.attr("style","display:none");
                        form.attr("target","");
                        form.attr("method","post");
                        form.attr("action","./dialogueManagement.do");
                        var input1=$("<input>");
                        input1.attr("type","hidden");
                        input1.attr("name","method");
                        input1.attr("value","downloadByFormByChatRecord");
                        var input2=$("<input>");
                        input2.attr("type","hidden");
                        input2.attr("name","filePath");
                        input2.attr("value",url);
                        $("body").append(form);//将表单放置在web中
                        form.append(input1).append(input2);
                        form.submit();//表单提交
                    } catch(e) {}
				})
			})
			//下载图片
			$(".all_col .tools .glyphicon-download-alt").parent().on("click",function(){
				try {
                        //如果成功，使用form表单进行下载
                        var form=$("<form>");//定义一个form表单
                        form.attr("style","display:none");
                        form.attr("target","");
                        form.attr("method","post");
                        form.attr("action","./dialogueManagement.do");
                        var input1=$("<input>");
                        input1.attr("type","hidden");
                        input1.attr("name","method");
                        input1.attr("value","downloadPics");
                        var input2=$("<input>");
                        input2.attr("type","hidden");
                        input2.attr("name","chatRecordPk");
                        input2.attr("value",selectedPk);
                        $("body").append(form);//将表单放置在web中
                        form.append(input1).append(input2);
                        form.submit();//表单提交
                    } catch(e) {}
				
			})
			$("#qcModal .qd").on("click",function(event){
				var list = $.validationCheck(["#qcModal .qcModalBody>div"])
				if(list.success==true && list.list.length>0){
					main.msg({type:"error",id:"qc",message:list.list[0],hideAfter:2});
					return false;
				}
				$.ajax({url: "./dialogueManagement.do",data:{method:"saveChatRecordScore",score:$(".qcModalBody .score").getValue(),pk:selectedPk}})
				.done(function(e){
					$.ajax({url: "./dialogueManagement.do",data:{method:"addQc",pk:selectedPk}})
					.done(function(e){
						main.msg({id:"zj",message:""+ JtalkManager_WebContent_bootstrapUI_js_running_application_dialogueManagement_js_194 +"",hideAfter:2});
						$("#qcModal").modalHide();
						$(".selections .search").click();
					})
				})
			});
			$("#remarkModal .qd").on("click",function(event){
				var list = $.validationCheck(["#remarkModal .remarkModalBody>div"])
				if(list.success==true && list.list.length>0){
					main.msg({type:"error",id:"remark",message:list.list[0],hideAfter:2});
					return false;
				}
				$.ajax({type:"POST",url: "./dialogueManagement.do",data:{method:"saveChatRecordMemo",memo:$("#remarkModal .remark").getValue(),pk:selectedPk}})
				.done(function(e){
					$("#remarkModal").modalHide();
					$(".selections .search").click();
				})
			});
			
			$("body").delegate("#dialogueManageTable tbody tr[data-index] .wxReply","click",function(el){
				var $this= $(this);	
				var index = $this.parents("tr[data-index]").data("index");
				var item = $("#dialogueManageTable").getValue()[index];
				$("#wxReplyModal").modalShow();
				$("#wxReplyModal .wxReplyLabel").setValue(item.visitorName);
				$("#wxReplyModal .wxReplyTextarea").setValue("");
			});
			$("#wxReplyModal .qd").on('click', function(event) {
				var list = $.validationCheck(["#wxReplyModal .wxReplyModalBody>div"])
				if(list.success==true && list.list.length>0){
					main.msg({type:"error",id:"wx",message:list.list[0],hideAfter:2});
					return false;
				}
				$.ajax({type:"POST",url:"./dialogueManagement.do",data:{
					method : 'saveChatRecordSend',
					pk : selectedPk,
					content:$("#wxReplyModal .wxReplyTextarea").getValue()
				},dataType:"json"}).done(function(e){
					main.msg({id:"wx",message:e.msg,hideAfter:2});
					$("#wxReplyModal").modalHide();
				})
			});
		});
	})
	$(window).unload(function(){
		delete window.download;
	})
})(jQuery);
