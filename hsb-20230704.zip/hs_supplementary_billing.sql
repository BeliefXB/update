/*
 Navicat Premium Data Transfer

 Source Server         : 192.168.11.76--恒生dev
 Source Server Type    : PostgreSQL
 Source Server Version : 110007
 Source Host           : 192.168.11.76:5432
 Source Catalog        : hswo
 Source Schema         : public

 Target Server Type    : PostgreSQL
 Target Server Version : 110007
 File Encoding         : 65001

 Date: 04/07/2023 10:12:06
*/


-- ----------------------------
-- Table structure for hs_supplementary_billing
-- ----------------------------
DROP TABLE IF EXISTS "public"."hs_supplementary_billing";
CREATE TABLE "public"."hs_supplementary_billing" (
  "serial_number" varchar(30) COLLATE "pg_catalog"."default" NOT NULL DEFAULT NULL,
  "account_currency" varchar(30) COLLATE "pg_catalog"."default" DEFAULT NULL,
  "account_name" varchar(30) COLLATE "pg_catalog"."default" DEFAULT NULL,
  "account_num" varchar(30) COLLATE "pg_catalog"."default" DEFAULT NULL,
  "application_time" varchar(30) COLLATE "pg_catalog"."default" DEFAULT NULL,
  "billing_end_time" varchar(30) COLLATE "pg_catalog"."default" DEFAULT NULL,
  "billing_start_time" varchar(30) COLLATE "pg_catalog"."default" DEFAULT NULL,
  "branch_name" varchar(30) COLLATE "pg_catalog"."default" DEFAULT NULL,
  "collection_method" varchar(30) COLLATE "pg_catalog"."default" DEFAULT NULL,
  "confirm_charge" varchar(30) COLLATE "pg_catalog"."default" DEFAULT NULL,
  "consultation_content" varchar(255) COLLATE "pg_catalog"."default" DEFAULT NULL,
  "customer_address" varchar(255) COLLATE "pg_catalog"."default" DEFAULT NULL,
  "customer_level" varchar(30) COLLATE "pg_catalog"."default" DEFAULT NULL,
  "customer_name" varchar(30) COLLATE "pg_catalog"."default" DEFAULT NULL,
  "customer_no" varchar(30) COLLATE "pg_catalog"."default" DEFAULT NULL,
  "deduction_account" varchar(30) COLLATE "pg_catalog"."default" DEFAULT NULL,
  "fee_estimation" varchar(30) COLLATE "pg_catalog"."default" DEFAULT NULL,
  "rm_code" varchar(30) COLLATE "pg_catalog"."default" DEFAULT NULL,
  "service_category" varchar(30) COLLATE "pg_catalog"."default" DEFAULT NULL,
  "telephone" varchar(30) COLLATE "pg_catalog"."default" DEFAULT NULL,
  "status" varchar(20) COLLATE "pg_catalog"."default" DEFAULT NULL,
  "business_type" int4 DEFAULT NULL,
  "operater" varchar(40) COLLATE "pg_catalog"."default" DEFAULT NULL,
  "work_id" varchar(30) COLLATE "pg_catalog"."default" DEFAULT NULL,
  "consumer_loans" varchar(30) COLLATE "pg_catalog"."default" DEFAULT NULL
)
;

-- ----------------------------
-- Primary Key structure for table hs_supplementary_billing
-- ----------------------------
ALTER TABLE "public"."hs_supplementary_billing" ADD CONSTRAINT "hs_supplementary_billing_pkey" PRIMARY KEY ("serial_number");
